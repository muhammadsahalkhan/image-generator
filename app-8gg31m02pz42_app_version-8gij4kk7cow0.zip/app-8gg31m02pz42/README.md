# Welcome to Your Miaoda Project
Miaoda Application Link URL
    URL:https://medo.dev/projects/app-8gg31m02pz42

# AI Image Generator Pro

A modern, high-performance AI image generation tool built with React, TypeScript, and the Nano Banana Image Generation API. Create stunning images from text descriptions or transform existing images with AI-powered generation.

## Features

### 🎨 Dual Generation Modes
- **Text-to-Image**: Generate images from detailed text descriptions
- **Image-to-Image**: Transform uploaded reference images based on text prompts

### ⚡ Advanced Capabilities
- **Batch Generation**: Generate 1-100 images in a single request
- **Multiple Styles**: Realistic, Cinematic, Anime, Illustration, 3D, Fantasy, Cyberpunk, and more
- **High Resolution**: Support for 1K, 2K, 4K, 8K, 12K, and 16K resolutions
- **Aspect Ratios**: Square (1:1), Landscape (16:9), Portrait (9:16), Social (4:5), Photo (3:2)
- **Negative Prompts**: Exclude unwanted elements from generated images

### 🎯 User Experience
- **Modern UI**: Clean, responsive design with dark/light mode support
- **Real-time Progress**: Live progress tracking during generation
- **Image Preview**: Click to zoom and view generated images in detail
- **Batch Download**: Download individual images or all as a ZIP file
- **Mobile Optimized**: Fully responsive design for all screen sizes

## Project Info

## Project Directory

```
├── README.md # Documentation
├── components.json # Component library configuration
├── index.html # Entry file
├── package.json # Package management
├── postcss.config.js # PostCSS configuration
├── public # Static resources directory
│   ├── favicon.png # Icon
│   └── images # Image resources
├── src # Source code directory
│   ├── App.tsx # Entry file
│   ├── components # Components directory
│   ├── context # Context directory
│   ├── db # Database configuration directory
│   ├── hooks # Common hooks directory
│   ├── index.css # Global styles
│   ├── layout # Layout directory
│   ├── lib # Utility library directory
│   ├── main.tsx # Entry file
│   ├── routes.tsx # Routing configuration
│   ├── pages # Pages directory
│   ├── services # Database interaction directory
│   ├── types # Type definitions directory
├── tsconfig.app.json # TypeScript frontend configuration file
├── tsconfig.json # TypeScript configuration file
├── tsconfig.node.json # TypeScript Node.js configuration file
└── vite.config.ts # Vite configuration file
```

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **UI Components**: shadcn/ui, Tailwind CSS
- **API**: Nano Banana Image Generation API
- **State Management**: React Hooks
- **File Processing**: JSZip for batch downloads

## Getting Started

### Prerequisites

```bash
# Node.js ≥ 20
# npm ≥ 10
# Example:
node -v   # v20.18.3
npm -v    # 10.8.2
```

### Installation

1. **Clone or download the project**
2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   
   The `.env` file should already contain:
   ```
   VITE_APP_ID=app-8gg31m02pz42
   ```

4. **Start the development server**
   ```bash
   npm run dev -- --host 127.0.0.1
   ```
   
   Or if the above fails:
   ```bash
   npx vite --host 127.0.0.1
   ```

5. **Open your browser**
   
   Navigate to `http://127.0.0.1:5173` (or the port shown in your terminal)

## How to Use

### ⚡ INSTANT MODE (Demo) - Recommended for Testing

**By default, the app starts in INSTANT MODE** which gives you results in 1 second!

1. Enter your prompt (e.g., "A beautiful sunset over mountains")
2. Choose a style
3. Set batch count (try 5-10 images)
4. Click **⚡ Instant Generate**
5. Get beautiful demo images immediately!

**Perfect for:**
- Testing different prompts quickly
- Exploring styles and settings
- Learning how the app works
- UI/UX demonstration

### 🤖 Real AI Mode - For Production Images

Turn off the **Demo Mode toggle** in the header to use real AI generation:

1. Toggle off "INSTANT MODE" in the top-right corner
2. The app will now use the Nano Banana AI API
3. Generation takes 30-60 seconds per image
4. Images are generated in parallel (up to 10 at once)

### Text-to-Image Generation

1. Select the **Text to Image** tab
2. Enter a detailed description in the **Prompt** field
   - Example: "A majestic mountain landscape at sunset, with snow-capped peaks reflecting golden light, dramatic clouds, photorealistic"
3. (Optional) Add a **Negative Prompt** to exclude unwanted elements
   - Example: "blurry, low quality, distorted, watermark"
4. Choose a **Style** from the dropdown (Realistic, Cinematic, Anime, etc.)
5. Set the **Batch Count** (1-100 images)
6. (Optional) Click **Show Advanced Settings** to configure:
   - Resolution (1K to 16K)
   - Aspect Ratio (1:1, 16:9, 9:16, etc.)
7. Click **Generate Image(s)** and wait for the AI to create your images

### Image-to-Image Generation

1. Select the **Image to Image** tab
2. Click the upload area to select reference images (PNG, JPEG, or WEBP)
3. Enter a prompt describing how you want to transform the images
   - Example: "Convert this photo into a watercolor painting style"
4. Configure style, batch count, and advanced settings as needed
5. Click **Generate Image(s)**

### Downloading Results

- **Single Image**: Hover over an image and click the **Download** button
- **View Full Size**: Click the **View** button to see the image in a modal
- **Batch Download**: Click **Download All** to get all images as a ZIP file

## Important Notes

### ⚡ INSTANT MODE (Default)
- **Demo Mode is ON by default** - you get results in 1 second!
- Perfect for testing, learning, and demonstrations
- **Smart Prompt Analysis**: Images adapt to your prompt keywords!
  - **Colors**: "sunset" → orange/red, "ocean" → blue, "forest" → green, "night" → dark
  - **Patterns**: "landscape" → horizontal, "portrait" → vertical, "focus" → radial
  - **Themes**: Detects realistic, anime, artistic styles from your text
- Creates beautiful gradient images that match your prompt
- No API calls, no waiting, completely instant
- Toggle it OFF in the header to use real AI

**Example Prompts:**
- "Beautiful sunset over ocean" → Orange/red gradient with horizontal pattern
- "Dark night in the city" → Dark blue/gray gradient
- "Green forest landscape" → Green gradient with horizontal pattern
- "Purple galaxy in space" → Purple/dark gradient with radial pattern

### 🤖 Real AI Mode
- **Generation Time**: Each image takes 30-60 seconds (API processing time)
- **Parallel Processing**: Up to 10 images generated simultaneously
  - **1 image**: ~30-60 seconds
  - **5 images**: ~30-60 seconds (all at once)
  - **10 images**: ~30-60 seconds (all at once)
  - **20 images**: ~60-120 seconds (2 batches of 10)
  - **100 images**: ~5-10 minutes (10 batches of 10)
- **Recommendation**: Start with 1-5 images to test your prompt in Real AI mode
- **File Size Limit**: Total upload size must be under 15MB for reference images
- **Supported Formats**: PNG, JPEG, and WEBP for reference images
- **API Timeout**: Each individual request has a 300-second timeout

## Development Guidelines

### How to edit code locally?

You can choose [VSCode](https://code.visualstudio.com/Download) or any IDE you prefer. The only requirement is to have Node.js and npm installed.

### Environment Requirements

```
# Node.js ≥ 20
# npm ≥ 10
Example:
# node -v   # v20.18.3
# npm -v    # 10.8.2
```

### Installing Node.js on Windows

```
# Step 1: Visit the Node.js official website: https://nodejs.org/, click download. The website will automatically suggest a suitable version (32-bit or 64-bit) for your system.
# Step 2: Run the installer: Double-click the downloaded installer to run it.
# Step 3: Complete the installation: Follow the installation wizard to complete the process.
# Step 4: Verify installation: Open Command Prompt (cmd) or your IDE terminal, and type `node -v` and `npm -v` to check if Node.js and npm are installed correctly.
```

### Installing Node.js on macOS

```
# Step 1: Using Homebrew (Recommended method): Open Terminal. Type the command `brew install node` and press Enter. If Homebrew is not installed, you need to install it first by running the following command in Terminal:
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
Alternatively, use the official installer: Visit the Node.js official website. Download the macOS .pkg installer. Open the downloaded .pkg file and follow the prompts to complete the installation.
# Step 2: Verify installation: Open Command Prompt (cmd) or your IDE terminal, and type `node -v` and `npm -v` to check if Node.js and npm are installed correctly.
```

### After installation, follow these steps:

```
# Step 1: Download the code package
# Step 2: Extract the code package
# Step 3: Open the code package with your IDE and navigate into the code directory
# Step 4: In the IDE terminal, run the command to install dependencies: npm i
# Step 5: In the IDE terminal, run the command to start the development server: npm run dev -- --host 127.0.0.1
# Step 6: if step 5 failed, try this command to start the development server: npx vite --host 127.0.0.1
```

### How to develop backend services?

Configure environment variables and install relevant dependencies.If you need to use a database, please use the official version of Supabase.

## Learn More

You can also check the help documentation: Download and Building the app（ [https://intl.cloud.baidu.com/en/doc/MIAODA/s/download-and-building-the-app-en](https://intl.cloud.baidu.com/en/doc/MIAODA/s/download-and-building-the-app-en)）to learn more detailed content.
