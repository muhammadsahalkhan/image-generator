# 🧠 Smart Demo Mode - Test Examples

## Ab Prompt Aur Image Match Karti Hain! (اب پرامپٹ اور امیج میچ کرتی ہیں!)

### Test Karne Ke Liye Prompts (ٹیسٹ کرنے کے لیے پرامپٹس)

#### 1. Sunset/Sunrise (غروب آفتاب)
```
Prompt: "Beautiful sunset over the ocean"
Expected: Orange/Red gradient (horizontal pattern)
Keywords Detected: sunset, ocean
```

```
Prompt: "Sunrise in the mountains"
Expected: Orange/Red gradient
Keywords Detected: sunrise, mountain
```

#### 2. Ocean/Water (سمندر/پانی)
```
Prompt: "Deep blue ocean with waves"
Expected: Blue gradient
Keywords Detected: ocean, blue
```

```
Prompt: "Peaceful beach with water"
Expected: Blue gradient
Keywords Detected: beach, water
```

#### 3. Forest/Nature (جنگل/قدرت)
```
Prompt: "Green forest with tall trees"
Expected: Green gradient
Keywords Detected: forest, green, tree
```

```
Prompt: "Jungle landscape with nature"
Expected: Green gradient (horizontal pattern)
Keywords Detected: jungle, landscape, nature
```

#### 4. Night/Dark (رات/اندھیرا)
```
Prompt: "Dark night in the city"
Expected: Dark blue/black gradient
Keywords Detected: night, dark, city
```

```
Prompt: "Midnight sky with stars"
Expected: Dark gradient
Keywords Detected: midnight
```

#### 5. Fire/Flame (آگ/شعلہ)
```
Prompt: "Burning fire with flames"
Expected: Red/Gold gradient
Keywords Detected: fire, flame
```

```
Prompt: "Lava flowing from volcano"
Expected: Red/Gold gradient
Keywords Detected: lava
```

#### 6. Ice/Snow (برف/ثلج)
```
Prompt: "Frozen ice in winter"
Expected: Light blue/white gradient
Keywords Detected: ice, frozen, winter
```

```
Prompt: "Snow covered mountains"
Expected: Light blue/white gradient
Keywords Detected: snow, mountain
```

#### 7. Desert/Sand (صحرا/ریت)
```
Prompt: "Desert landscape with sand dunes"
Expected: Tan/Brown gradient (horizontal pattern)
Keywords Detected: desert, sand, landscape
```

#### 8. Space/Galaxy (خلا/کہکشاں)
```
Prompt: "Purple galaxy in space"
Expected: Purple/Dark gradient (radial pattern)
Keywords Detected: galaxy, space, purple
```

```
Prompt: "Cosmic nebula with stars"
Expected: Purple/Dark gradient
Keywords Detected: cosmic, nebula
```

#### 9. City/Urban (شہر)
```
Prompt: "Modern city with tall buildings"
Expected: Gray/Dark gradient
Keywords Detected: city, building
```

```
Prompt: "Urban landscape at night"
Expected: Dark gradient (horizontal pattern)
Keywords Detected: urban, landscape, night
```

#### 10. Flowers/Garden (پھول/باغ)
```
Prompt: "Beautiful flower garden"
Expected: Pink gradient
Keywords Detected: flower, garden
```

```
Prompt: "Blooming flowers in spring"
Expected: Pink gradient
Keywords Detected: flower, bloom
```

#### 11. Portrait (پورٹریٹ)
```
Prompt: "Portrait of a person"
Expected: Vertical gradient pattern
Keywords Detected: portrait, person
```

```
Prompt: "Face of a beautiful woman"
Expected: Vertical gradient pattern
Keywords Detected: face
```

#### 12. Landscape (لینڈسکیپ)
```
Prompt: "Mountain landscape with horizon"
Expected: Horizontal gradient pattern
Keywords Detected: landscape, horizon, mountain
```

```
Prompt: "Panoramic view of the valley"
Expected: Horizontal gradient pattern
Keywords Detected: panorama
```

#### 13. Color Keywords (رنگ کے الفاظ)
```
Prompt: "Red rose in the garden"
Expected: Red gradient
Keywords Detected: red
```

```
Prompt: "Blue sky with clouds"
Expected: Blue gradient
Keywords Detected: blue
```

```
Prompt: "Green grass field"
Expected: Green gradient
Keywords Detected: green
```

```
Prompt: "Purple violet flowers"
Expected: Purple gradient
Keywords Detected: purple, violet
```

```
Prompt: "Golden luxury watch"
Expected: Gold gradient
Keywords Detected: gold, golden, luxury
```

#### 14. Combined Keywords (ملے جلے الفاظ)
```
Prompt: "Beautiful sunset over green forest landscape"
Expected: Orange/Red + Green gradient (horizontal pattern)
Keywords Detected: sunset (priority), forest, landscape
Note: First detected color wins
```

```
Prompt: "Dark night in the city with blue lights"
Expected: Dark gradient
Keywords Detected: night (priority), dark, city, blue
```

```
Prompt: "Portrait of person in purple galaxy"
Expected: Purple gradient (vertical pattern)
Keywords Detected: portrait (pattern), purple, galaxy
```

## How It Works (یہ کیسے کام کرتا ہے)

### Priority System:
1. **First color keyword found** = Main color
2. **First pattern keyword found** = Pattern type
3. **Style fallback** = If no keywords, use style colors

### Keyword Categories:

**Colors (16 types):**
- Sunset/Sunrise, Ocean/Water, Forest/Nature, Night/Dark
- Fire/Flame, Ice/Snow, Desert/Sand, Space/Galaxy
- City/Urban, Flower/Garden, Mountain, Gold/Luxury
- Purple, Red, Blue, Green

**Patterns (3 types):**
- Landscape/Horizon → Horizontal
- Portrait/Person/Face → Vertical
- Center/Focus → Radial
- Default → Diagonal

**Themes (3 types):**
- Realistic/Photo
- Anime/Manga
- Painting/Art

### Urdu Support (اردو سپورٹ):
Keywords also work in Urdu:
- غروب (sunset)
- سمندر (ocean)
- جنگل (forest)
- رات (night)
- آگ (fire)
- برف (snow)
- صحرا (desert)
- خلا (space)
- شہر (city)
- پھول (flower)
- پہاڑ (mountain)
- سونا (gold)
- جامنی (purple)
- لال (red)
- نیلا (blue)
- ہرا (green)

## Testing Tips (ٹیسٹنگ ٹپس)

1. **Try single keywords first**: "sunset", "ocean", "forest"
2. **Then combine**: "sunset over ocean", "dark night city"
3. **Test patterns**: "landscape", "portrait", "focus"
4. **Test colors**: "red", "blue", "green", "purple"
5. **Mix everything**: "beautiful sunset landscape with purple sky"

## Expected Behavior (متوقع رویہ)

✅ **Prompt with keywords** → Matching colors and patterns  
✅ **Prompt without keywords** → Style-based colors  
✅ **Multiple keywords** → First detected wins  
✅ **Urdu keywords** → Same as English  
✅ **Case insensitive** → "SUNSET" = "sunset" = "Sunset"

## Quick Test (فوری ٹیسٹ)

1. Open app (Demo Mode ON by default)
2. Type: "Beautiful sunset over the ocean"
3. Click: ⚡ Instant Generate
4. Result: Orange/Red gradient with horizontal pattern ✅
5. Type: "Dark night in the city"
6. Click: ⚡ Instant Generate
7. Result: Dark blue/black gradient ✅
8. Type: "Green forest landscape"
9. Click: ⚡ Instant Generate
10. Result: Green gradient with horizontal pattern ✅

**Ab prompt aur image match karti hain!** ✅🎨
