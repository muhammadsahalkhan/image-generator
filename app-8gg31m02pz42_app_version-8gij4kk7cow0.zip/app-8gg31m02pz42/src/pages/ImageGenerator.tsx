import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { 
  Wand2, 
  Image as ImageIcon, 
  Upload, 
  Download, 
  Loader2, 
  X, 
  ZoomIn,
  Sparkles,
  Settings2,
  AlertCircle,
  Zap
} from 'lucide-react';
import { generateBatchImages, fileToBase64 } from '@/services/imageGeneration';
import { useToast } from '@/hooks/use-toast';
import JSZip from 'jszip';

const STYLES = [
  { value: 'none', label: 'None' },
  { value: 'realistic', label: 'Realistic' },
  { value: 'cinematic', label: 'Cinematic' },
  { value: 'anime', label: 'Anime' },
  { value: 'illustration', label: 'Illustration' },
  { value: '3d render', label: '3D Render' },
  { value: 'fantasy', label: 'Fantasy' },
  { value: 'cyberpunk', label: 'Cyberpunk' },
  { value: 'oil painting', label: 'Oil Painting' },
  { value: 'watercolor', label: 'Watercolor' },
  { value: 'sketch', label: 'Sketch' },
];

const RESOLUTIONS = [
  { value: '1024x1024', label: '1K (1024×1024)' },
  { value: '2048x2048', label: '2K (2048×2048)' },
  { value: '3840x2160', label: '4K (3840×2160)' },
  { value: '7680x4320', label: '8K (7680×4320)' },
  { value: '11520x6480', label: '12K (11520×6480)' },
  { value: '15360x8640', label: '16K (15360×8640)' },
];

const ASPECT_RATIOS = [
  { value: '1:1', label: '1:1 (Square)' },
  { value: '16:9', label: '16:9 (Landscape)' },
  { value: '9:16', label: '9:16 (Portrait)' },
  { value: '4:5', label: '4:5 (Social)' },
  { value: '3:2', label: '3:2 (Photo)' },
];

export default function ImageGenerator() {
  const [mode, setMode] = useState<'text-to-image' | 'image-to-image'>('text-to-image');
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [style, setStyle] = useState('realistic');
  const [batchCount, setBatchCount] = useState(1);
  const [resolution, setResolution] = useState('2048x2048');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [referenceImages, setReferenceImages] = useState<File[]>([]);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [demoMode, setDemoMode] = useState(true); // Default: Demo Mode ON for instant results
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => 
      file.type === 'image/png' || 
      file.type === 'image/jpeg' || 
      file.type === 'image/webp'
    );

    if (validFiles.length !== files.length) {
      toast({
        title: 'Invalid file type',
        description: 'Only PNG, JPEG, and WEBP images are supported.',
        variant: 'destructive',
      });
    }

    // Check file size (20MB limit for total request)
    const totalSize = validFiles.reduce((sum, file) => sum + file.size, 0);
    if (totalSize > 15 * 1024 * 1024) { // 15MB to leave room for other data
      toast({
        title: 'Files too large',
        description: 'Total file size must be under 15MB.',
        variant: 'destructive',
      });
      return;
    }

    setReferenceImages(prev => [...prev, ...validFiles]);
  };

  const removeReferenceImage = (index: number) => {
    setReferenceImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: 'Prompt required',
        description: 'Please enter a description for the image you want to generate.',
        variant: 'destructive',
      });
      return;
    }

    if (mode === 'image-to-image' && referenceImages.length === 0 && !demoMode) {
      toast({
        title: 'Reference image required',
        description: 'Please upload at least one reference image for image-to-image generation.',
        variant: 'destructive',
      });
      return;
    }

    setIsGenerating(true);
    setProgress(0);
    setGeneratedImages([]);

    try {
      // Convert reference images to Base64
      let base64Images: string[] = [];
      if (mode === 'image-to-image' && referenceImages.length > 0 && !demoMode) {
        base64Images = await Promise.all(
          referenceImages.map(file => fileToBase64(file))
        );
      }

      // Add resolution and aspect ratio to prompt (only for real AI mode)
      const enhancedPrompt = demoMode 
        ? prompt 
        : `${prompt}, ${resolution} resolution, ${aspectRatio} aspect ratio, high quality, detailed`;

      const images = await generateBatchImages(
        {
          prompt: enhancedPrompt,
          negativePrompt,
          referenceImages: base64Images,
          style,
          demoMode, // Pass demo mode flag
        },
        batchCount,
        (current, total) => {
          setProgress((current / total) * 100);
        }
      );

      setGeneratedImages(images);
      toast({
        title: demoMode ? '✨ Demo Images Ready!' : 'Success!',
        description: `Generated ${images.length} image${images.length > 1 ? 's' : ''} ${demoMode ? '(Demo Mode - Instant Results)' : 'successfully'}.`,
      });
    } catch (error) {
      console.error('Generation error:', error);
      toast({
        title: 'Generation failed',
        description: error instanceof Error ? error.message : 'An unknown error occurred.',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
      setProgress(0);
    }
  };

  const downloadImage = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `ai-generated-${Date.now()}-${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAllAsZip = async () => {
    if (generatedImages.length === 0) return;

    try {
      const zip = new JSZip();
      const timestamp = Date.now();

      for (let i = 0; i < generatedImages.length; i++) {
        const imageUrl = generatedImages[i];
        const base64Data = imageUrl.split(',')[1];
        zip.file(`ai-generated-${timestamp}-${i + 1}.png`, base64Data, { base64: true });
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = `ai-images-${timestamp}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);

      toast({
        title: 'Download complete',
        description: `Downloaded ${generatedImages.length} images as ZIP.`,
      });
    } catch (error) {
      toast({
        title: 'Download failed',
        description: 'Failed to create ZIP file.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
                <Sparkles className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">AI Image Generator Pro</h1>
                <p className="text-sm text-muted-foreground">Create stunning images with AI</p>
              </div>
            </div>
            
            {/* Demo Mode Toggle */}
            <div className="flex items-center gap-3 rounded-lg border-2 border-primary/20 bg-card p-3 shadow-sm">
              <Zap className={`h-5 w-5 ${demoMode ? 'text-primary animate-pulse' : 'text-muted-foreground'}`} />
              <div className="flex flex-col gap-0.5">
                <Label htmlFor="demo-mode" className="text-sm font-semibold cursor-pointer">
                  {demoMode ? '⚡ INSTANT MODE (Demo)' : '🤖 Real AI (Slow)'}
                </Label>
                <p className="text-xs text-muted-foreground">
                  {demoMode ? 'Get results in 1 second!' : 'Takes 30-60 sec per image'}
                </p>
              </div>
              <Switch
                id="demo-mode"
                checked={demoMode}
                onCheckedChange={setDemoMode}
                className="data-[state=checked]:bg-primary"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6 xl:grid-cols-[1fr_400px]">
          {/* Left Panel - Controls */}
          <div className="space-y-6">
            {/* Mode Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Generation Mode</CardTitle>
                <CardDescription>Choose how you want to create your image</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={mode} onValueChange={(v) => setMode(v as typeof mode)}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="text-to-image" className="gap-2">
                      <Wand2 className="h-4 w-4" />
                      Text to Image
                    </TabsTrigger>
                    <TabsTrigger value="image-to-image" className="gap-2">
                      <ImageIcon className="h-4 w-4" />
                      Image to Image
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardContent>
            </Card>

            {/* Reference Images (Image-to-Image mode) */}
            {mode === 'image-to-image' && (
              <Card>
                <CardHeader>
                  <CardTitle>Reference Images</CardTitle>
                  <CardDescription>Upload images to use as reference (PNG, JPEG, WEBP)</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-muted/50 p-8 transition-colors hover:border-primary hover:bg-muted"
                  >
                    <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                    <p className="text-sm font-medium text-foreground">Click to upload images</p>
                    <p className="text-xs text-muted-foreground">PNG, JPEG, or WEBP (max 15MB total)</p>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    multiple
                    className="hidden"
                    onChange={handleFileUpload}
                  />

                  {referenceImages.length > 0 && (
                    <div className="grid grid-cols-2 gap-4 @md:grid-cols-3">
                      {referenceImages.map((file, index) => (
                        <div key={index} className="group relative aspect-square overflow-hidden rounded-lg border border-border">
                          <img
                            src={URL.createObjectURL(file)}
                            alt={`Reference ${index + 1}`}
                            className="h-full w-full object-cover"
                          />
                          <button
                            onClick={() => removeReferenceImage(index)}
                            className="absolute right-2 top-2 rounded-full bg-destructive p-1 opacity-0 transition-opacity group-hover:opacity-100"
                          >
                            <X className="h-4 w-4 text-destructive-foreground" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Prompt Input */}
            <Card>
              <CardHeader>
                <CardTitle>Prompt</CardTitle>
                <CardDescription>Describe the image you want to generate</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="prompt">Description</Label>
                  <Textarea
                    id="prompt"
                    placeholder="A majestic mountain landscape at sunset, with snow-capped peaks reflecting golden light, dramatic clouds, photorealistic..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={4}
                    className="resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="negative-prompt">Negative Prompt (Optional)</Label>
                  <Textarea
                    id="negative-prompt"
                    placeholder="blurry, low quality, distorted, watermark..."
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    rows={2}
                    className="resize-none"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Basic Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Settings</CardTitle>
                <CardDescription>Configure your image generation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-6 @md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="style">Style</Label>
                    <Select value={style} onValueChange={setStyle}>
                      <SelectTrigger id="style">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STYLES.map((s) => (
                          <SelectItem key={s.value} value={s.value}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="batch-count">Batch Count: {batchCount}</Label>
                    <div className="flex gap-2">
                      <Slider
                        id="batch-count"
                        min={1}
                        max={100}
                        step={1}
                        value={[batchCount]}
                        onValueChange={(v) => setBatchCount(v[0])}
                        className="flex-1"
                      />
                      <Input
                        type="number"
                        min={1}
                        max={100}
                        value={batchCount}
                        onChange={(e) => setBatchCount(Math.max(1, Math.min(100, parseInt(e.target.value) || 1)))}
                        className="w-20"
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Advanced Settings Toggle */}
                <Button
                  variant="outline"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="w-full"
                >
                  <Settings2 className="mr-2 h-4 w-4" />
                  {showAdvanced ? 'Hide' : 'Show'} Advanced Settings
                </Button>

                {showAdvanced && (
                  <div className="space-y-4 rounded-lg border border-border bg-muted/50 p-4">
                    <div className="space-y-2">
                      <Label htmlFor="resolution">Resolution</Label>
                      <Select value={resolution} onValueChange={setResolution}>
                        <SelectTrigger id="resolution">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {RESOLUTIONS.map((r) => (
                            <SelectItem key={r.value} value={r.value}>
                              {r.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="aspect-ratio">Aspect Ratio</Label>
                      <Select value={aspectRatio} onValueChange={setAspectRatio}>
                        <SelectTrigger id="aspect-ratio">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ASPECT_RATIOS.map((r) => (
                            <SelectItem key={r.value} value={r.value}>
                              {r.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        Note: Resolution and aspect ratio are guidance for the AI. Actual output may vary.
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Generate Button */}
            <Card>
              <CardContent className="pt-6">
                {demoMode ? (
                  <Alert className="mb-4 border-primary/50 bg-primary/5">
                    <Zap className="h-4 w-4 text-primary" />
                    <AlertDescription className="text-xs">
                      <strong className="text-primary">⚡ INSTANT MODE:</strong> You'll get beautiful demo images in 1 second! 
                      Perfect for testing prompts and UI. Turn off Demo Mode in the header to use real AI (slower).
                    </AlertDescription>
                  </Alert>
                ) : (
                  <Alert className="mb-4">
                    <Sparkles className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      <strong>Real AI Mode:</strong> Images generated in parallel (up to 10 simultaneously). 
                      Each takes 30-60 seconds. Start with 1-5 images to test your prompt.
                    </AlertDescription>
                  </Alert>
                )}

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      {demoMode ? 'Creating Demo...' : 'Generating...'} {Math.round(progress)}%
                    </>
                  ) : (
                    <>
                      {demoMode ? <Zap className="mr-2 h-5 w-5" /> : <Sparkles className="mr-2 h-5 w-5" />}
                      {demoMode ? '⚡ Instant Generate' : 'Generate'} {batchCount > 1 ? `${batchCount} Images` : 'Image'}
                    </>
                  )}
                </Button>

                {isGenerating && (
                  <div className="mt-4 space-y-2">
                    <Progress value={progress} className="h-2" />
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <p>
                        {demoMode ? 'Creating instant demo images...' : 'Processing in parallel (up to 10 at once)'}
                      </p>
                      <p className="font-medium">
                        {Math.round(progress)}%
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Results */}
          <div className="space-y-6">
            <Card className="sticky top-4">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Generated Images</CardTitle>
                    <CardDescription>
                      {generatedImages.length > 0
                        ? `${generatedImages.length} image${generatedImages.length > 1 ? 's' : ''} generated`
                        : 'Your images will appear here'}
                    </CardDescription>
                  </div>
                  {generatedImages.length > 1 && (
                    <Button onClick={downloadAllAsZip} variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download All
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {generatedImages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-muted/50 p-12">
                    <ImageIcon className="mb-4 h-12 w-12 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">No images generated yet</p>
                  </div>
                ) : (
                  <div className="grid max-h-[calc(100vh-250px)] gap-4 overflow-y-auto pr-2">
                    {generatedImages.map((imageUrl, index) => (
                      <div
                        key={index}
                        className="group relative overflow-hidden rounded-lg border border-border bg-muted"
                      >
                        <img
                          src={imageUrl}
                          alt={`Generated ${index + 1}`}
                          crossOrigin="anonymous"
                          className="w-full object-contain"
                        />
                        <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/50 opacity-0 transition-opacity group-hover:opacity-100">
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setSelectedImage(imageUrl)}
                          >
                            <ZoomIn className="mr-2 h-4 w-4" />
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => downloadImage(imageUrl, index)}
                          >
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                        </div>
                        <Badge className="absolute right-2 top-2" variant="secondary">
                          #{index + 1}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Image Preview Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Image Preview</DialogTitle>
          </DialogHeader>
          {selectedImage && (
            <div className="relative">
              <img
                src={selectedImage}
                alt="Preview"
                crossOrigin="anonymous"
                className="w-full rounded-lg"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
