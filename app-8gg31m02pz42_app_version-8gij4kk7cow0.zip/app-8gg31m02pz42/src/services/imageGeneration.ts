// Nano Banana Image Generation API Service
const API_URL = 'https://api-integrations.appmedo.com/app-8gg31m02pz42/api-Xa6JZ58oPMEa/v1beta/models/gemini-3-pro-image-preview:generateContent';
const APP_ID = import.meta.env.VITE_APP_ID || 'app-8gg31m02pz42';

export interface ImageGenerationRequest {
  prompt: string;
  negativePrompt?: string;
  referenceImages?: string[]; // Base64 encoded images
  style?: string;
  demoMode?: boolean; // فوری ڈیمو امیجز کے لیے
}

export interface ImageGenerationResponse {
  status: number;
  msg: string;
  candidates: Array<{
    content: {
      role: string;
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
    safetyRatings: unknown[];
  }>;
}

/**
 * Convert file to Base64 string
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data URL prefix (e.g., "data:image/png;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

/**
 * Extract Base64 image from Markdown format response
 */
export const extractBase64FromMarkdown = (markdown: string): string | null => {
  const regex = /!\[image\]\(data:image\/[^;]+;base64,([^)]+)\)/;
  const match = markdown.match(regex);
  if (match && match[1]) {
    return `data:image/png;base64,${match[1]}`;
  }
  return null;
};

/**
 * Analyze prompt for contextual image generation
 * پرامپٹ کا تجزیہ کریں تاکہ متعلقہ امیج بنائی جا سکے
 */
const analyzePrompt = (prompt: string): {
  colors: { start: string; end: string };
  pattern: 'horizontal' | 'vertical' | 'radial' | 'diagonal';
  theme: string;
} => {
  const lowerPrompt = prompt.toLowerCase();
  
  // Color detection based on keywords - رنگ کا پتہ لگائیں
  let colors = { start: '#6366F1', end: '#8B5CF6' }; // default
  
  if (lowerPrompt.includes('sunset') || lowerPrompt.includes('sunrise') || lowerPrompt.includes('dawn') || lowerPrompt.includes('غروب')) {
    colors = { start: '#FF6B35', end: '#F7931E' };
  } else if (lowerPrompt.includes('ocean') || lowerPrompt.includes('sea') || lowerPrompt.includes('water') || lowerPrompt.includes('beach') || lowerPrompt.includes('سمندر')) {
    colors = { start: '#0077BE', end: '#00B4D8' };
  } else if (lowerPrompt.includes('forest') || lowerPrompt.includes('jungle') || lowerPrompt.includes('tree') || lowerPrompt.includes('nature') || lowerPrompt.includes('جنگل')) {
    colors = { start: '#2D6A4F', end: '#52B788' };
  } else if (lowerPrompt.includes('night') || lowerPrompt.includes('dark') || lowerPrompt.includes('midnight') || lowerPrompt.includes('رات')) {
    colors = { start: '#1A1A2E', end: '#16213E' };
  } else if (lowerPrompt.includes('fire') || lowerPrompt.includes('flame') || lowerPrompt.includes('lava') || lowerPrompt.includes('آگ')) {
    colors = { start: '#FF4500', end: '#FFD700' };
  } else if (lowerPrompt.includes('ice') || lowerPrompt.includes('snow') || lowerPrompt.includes('winter') || lowerPrompt.includes('frozen') || lowerPrompt.includes('برف')) {
    colors = { start: '#A7C7E7', end: '#E0F4FF' };
  } else if (lowerPrompt.includes('desert') || lowerPrompt.includes('sand') || lowerPrompt.includes('dune') || lowerPrompt.includes('صحرا')) {
    colors = { start: '#EDC9AF', end: '#F4A460' };
  } else if (lowerPrompt.includes('space') || lowerPrompt.includes('galaxy') || lowerPrompt.includes('cosmic') || lowerPrompt.includes('nebula') || lowerPrompt.includes('خلا')) {
    colors = { start: '#0B0B3B', end: '#6A0572' };
  } else if (lowerPrompt.includes('city') || lowerPrompt.includes('urban') || lowerPrompt.includes('building') || lowerPrompt.includes('شہر')) {
    colors = { start: '#2C3E50', end: '#34495E' };
  } else if (lowerPrompt.includes('flower') || lowerPrompt.includes('garden') || lowerPrompt.includes('bloom') || lowerPrompt.includes('پھول')) {
    colors = { start: '#FF69B4', end: '#FFB6C1' };
  } else if (lowerPrompt.includes('mountain') || lowerPrompt.includes('peak') || lowerPrompt.includes('hill') || lowerPrompt.includes('پہاڑ')) {
    colors = { start: '#4A5568', end: '#718096' };
  } else if (lowerPrompt.includes('gold') || lowerPrompt.includes('golden') || lowerPrompt.includes('luxury') || lowerPrompt.includes('سونا')) {
    colors = { start: '#FFD700', end: '#FFA500' };
  } else if (lowerPrompt.includes('purple') || lowerPrompt.includes('violet') || lowerPrompt.includes('جامنی')) {
    colors = { start: '#8B5CF6', end: '#A78BFA' };
  } else if (lowerPrompt.includes('red') || lowerPrompt.includes('crimson') || lowerPrompt.includes('لال')) {
    colors = { start: '#DC2626', end: '#EF4444' };
  } else if (lowerPrompt.includes('blue') || lowerPrompt.includes('azure') || lowerPrompt.includes('نیلا')) {
    colors = { start: '#2563EB', end: '#3B82F6' };
  } else if (lowerPrompt.includes('green') || lowerPrompt.includes('emerald') || lowerPrompt.includes('ہرا')) {
    colors = { start: '#059669', end: '#10B981' };
  }
  
  // Pattern detection - پیٹرن کا پتہ لگائیں
  let pattern: 'horizontal' | 'vertical' | 'radial' | 'diagonal' = 'diagonal';
  
  if (lowerPrompt.includes('landscape') || lowerPrompt.includes('horizon') || lowerPrompt.includes('panorama')) {
    pattern = 'horizontal';
  } else if (lowerPrompt.includes('portrait') || lowerPrompt.includes('person') || lowerPrompt.includes('face')) {
    pattern = 'vertical';
  } else if (lowerPrompt.includes('center') || lowerPrompt.includes('focus') || lowerPrompt.includes('spotlight')) {
    pattern = 'radial';
  }
  
  // Theme detection - تھیم کا پتہ لگائیں
  let theme = 'abstract';
  if (lowerPrompt.includes('realistic') || lowerPrompt.includes('photo')) theme = 'realistic';
  else if (lowerPrompt.includes('anime') || lowerPrompt.includes('manga')) theme = 'anime';
  else if (lowerPrompt.includes('painting') || lowerPrompt.includes('art')) theme = 'artistic';
  
  return { colors, pattern, theme };
};

/**
 * Generate a demo/placeholder image instantly (for testing UI)
 * فوری ڈیمو امیج بنائیں - پرامپٹ کے مطابق
 */
const generateDemoImage = (prompt: string, style: string): string => {
  // Create a canvas with gradient and text
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  
  if (!ctx) return '';
  
  // Analyze prompt for contextual generation - پرامپٹ کا تجزیہ
  const analysis = analyzePrompt(prompt);
  
  // Style-based color schemes (fallback) - انداز کے مطابق رنگ
  const styleColorSchemes: Record<string, { start: string; end: string }> = {
    realistic: { start: '#4A90E2', end: '#7B68EE' },
    cinematic: { start: '#FF6B6B', end: '#4ECDC4' },
    anime: { start: '#FF69B4', end: '#FFD700' },
    illustration: { start: '#98D8C8', end: '#F7DC6F' },
    '3d render': { start: '#667EEA', end: '#764BA2' },
    fantasy: { start: '#FA8BFF', end: '#2BD2FF' },
    cyberpunk: { start: '#00F5FF', end: '#FF00FF' },
    'oil painting': { start: '#8B4513', end: '#DEB887' },
    watercolor: { start: '#87CEEB', end: '#FFB6C1' },
    sketch: { start: '#696969', end: '#D3D3D3' },
    none: { start: '#667EEA', end: '#764BA2' },
  };
  
  // Use prompt-based colors, fallback to style colors - پرامپٹ کے رنگ استعمال کریں
  const colors = analysis.colors.start !== '#6366F1' 
    ? analysis.colors 
    : (styleColorSchemes[style] || styleColorSchemes.none);
  
  // Create gradient based on pattern - پیٹرن کے مطابق گریڈینٹ
  let gradient;
  switch (analysis.pattern) {
    case 'horizontal':
      gradient = ctx.createLinearGradient(0, canvas.height / 2, canvas.width, canvas.height / 2);
      break;
    case 'vertical':
      gradient = ctx.createLinearGradient(canvas.width / 2, 0, canvas.width / 2, canvas.height);
      break;
    case 'radial':
      gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, canvas.width / 2
      );
      break;
    default: // diagonal
      gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  }
  
  gradient.addColorStop(0, colors.start);
  gradient.addColorStop(1, colors.end);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Add decorative elements
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  for (let i = 0; i < 20; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const radius = Math.random() * 100 + 50;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Add text
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.font = 'bold 48px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Wrap text
  const maxWidth = canvas.width - 100;
  const words = prompt.split(' ').slice(0, 10); // First 10 words
  const lines: string[] = [];
  let currentLine = '';
  
  words.forEach(word => {
    const testLine = currentLine + word + ' ';
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && currentLine !== '') {
      lines.push(currentLine);
      currentLine = word + ' ';
    } else {
      currentLine = testLine;
    }
  });
  lines.push(currentLine);
  
  const lineHeight = 60;
  const startY = (canvas.height - lines.length * lineHeight) / 2;
  
  lines.forEach((line, i) => {
    ctx.fillText(line.trim(), canvas.width / 2, startY + i * lineHeight);
  });
  
  // Add style badge
  ctx.font = 'bold 32px Arial';
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(20, 20, 300, 60);
  ctx.fillStyle = 'white';
  ctx.textAlign = 'left';
  ctx.fillText(`Style: ${style}`, 40, 55);
  
  // Add demo watermark
  ctx.font = 'bold 24px Arial';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.textAlign = 'center';
  ctx.fillText('ڈیمو موڈ - فوری نتیجہ', canvas.width / 2, canvas.height - 40);
  
  return canvas.toDataURL('image/png');
};

/**
 * Generate image using Nano Banana API
 * Nano Banana API استعمال کرتے ہوئے امیج بنائیں
 */
export const generateImage = async (
  request: ImageGenerationRequest
): Promise<string> => {
  // ڈیمو موڈ: فوری نتیجہ
  if (request.demoMode) {
    // Simulate a small delay for realism (0.5 seconds)
    await new Promise(resolve => setTimeout(resolve, 500));
    return generateDemoImage(request.prompt, request.style || 'none');
  }

  // اصل API کال
  try {
    const parts: Array<{ text?: string; inline_data?: { mime_type: string; data: string } }> = [];

    // Add reference images if provided
    if (request.referenceImages && request.referenceImages.length > 0) {
      for (const imageData of request.referenceImages) {
        parts.push({
          inline_data: {
            mime_type: 'image/png',
            data: imageData,
          },
        });
      }
    }

    // Build the prompt with style and negative prompt
    let fullPrompt = request.prompt;
    if (request.style && request.style !== 'none') {
      fullPrompt = `${request.prompt}, ${request.style} style`;
    }
    if (request.negativePrompt) {
      fullPrompt += `. Avoid: ${request.negativePrompt}`;
    }

    parts.push({ text: fullPrompt });

    const payload = {
      contents: [
        {
          parts,
        },
      ],
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-App-Id': APP_ID,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(300000), // 300s timeout
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data: ImageGenerationResponse = await response.json();

    // Handle API error responses
    if (data.status !== 0) {
      if (data.status === 999) {
        throw new Error(data.msg || 'API request failed');
      }
      throw new Error(data.msg || 'Unknown error occurred');
    }

    // Extract image from response
    if (data.candidates && data.candidates.length > 0) {
      const candidate = data.candidates[0];
      if (candidate.content.parts && candidate.content.parts.length > 0) {
        const markdown = candidate.content.parts[0].text;
        const imageUrl = extractBase64FromMarkdown(markdown);
        if (imageUrl) {
          return imageUrl;
        }
      }
    }

    throw new Error('No image generated in response');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to generate image');
  }
};

/**
 * Generate multiple images in batch with parallel processing
 */
export const generateBatchImages = async (
  request: ImageGenerationRequest,
  count: number,
  onProgress?: (current: number, total: number) => void
): Promise<string[]> => {
  const results: string[] = [];
  const errors: string[] = [];
  let completed = 0;

  // Determine optimal concurrency based on batch size
  // Small batches: process all at once
  // Large batches: process in chunks to avoid overwhelming the API
  const maxConcurrent = count <= 5 ? count : Math.min(10, count);
  
  // Create all promises
  const generatePromise = async (index: number): Promise<void> => {
    try {
      const imageUrl = await generateImage(request);
      results[index] = imageUrl;
      completed++;
      if (onProgress) {
        onProgress(completed, count);
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push(errorMsg);
      console.error(`Failed to generate image ${index + 1}:`, errorMsg);
      completed++;
      if (onProgress) {
        onProgress(completed, count);
      }
    }
  };

  // Process in batches with controlled concurrency
  const chunks: number[][] = [];
  for (let i = 0; i < count; i += maxConcurrent) {
    chunks.push(Array.from({ length: Math.min(maxConcurrent, count - i) }, (_, j) => i + j));
  }

  for (const chunk of chunks) {
    await Promise.all(chunk.map(index => generatePromise(index)));
  }

  // Filter out undefined results (failed generations)
  const successfulResults = results.filter(Boolean);

  if (successfulResults.length === 0 && errors.length > 0) {
    throw new Error(`All generations failed. First error: ${errors[0]}`);
  }

  return successfulResults;
};
